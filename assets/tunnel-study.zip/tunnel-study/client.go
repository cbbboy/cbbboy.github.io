package main

import (
	"fmt"
	"log"
	"os"
	"os/exec"
	"os/signal"
	"syscall"
	"tunnel-study/endpoint/netstack/stack"
	"tunnel-study/tun"
	"tunnel-study/tunnel"
)

func main() {
	// 启动虚拟网卡
	device, err := tun.CreateDevice("utun80", uint32(0))
	if err != nil {
		log.Fatalf("parse device error:%v", err)
	}

	// 初始化 虚拟端点
	_, err = stack.New(device, stack.WithDefault())
	if err != nil {
		log.Fatalf("parse device error:%v", err)
	}
	// 启动线程处理
	tunnel.InitProcess()
	// 设置路由
	//RunCmd("sudo", "ifconfig", e.Device, fmt.Sprintf("%s/32", VirtualIp), VirtualIp)
	// RunCmd("sudo", "route", "-n", "add", "-net", "1.0.0.0/8", "-gateway", VirtualIp, "-hopcount", "1")
	err = exec.Command("bash", "-c", fmt.Sprintf("sudo ifconfig utun80 114.2.2.2/24 114.2.2.2")).Run()
	if err != nil {
		log.Println(fmt.Sprintf("set ip err:%v", err))
	}
	setRoute("10.50.1.188/32")

	{
		var SigCh = make(chan os.Signal, 10)
		signal.Notify(SigCh, os.Interrupt, syscall.SIGTERM, syscall.SIGINT, syscall.SIGKILL)
		<-SigCh
	}
}

func setRoute(a string) {
	err := exec.Command("bash", "-c", fmt.Sprintf("sudo route delete %v", a)).Run()
	if err != nil {
		log.Println(fmt.Sprintf("set route err:%v", err))
	}

	err = exec.Command("bash", "-c", fmt.Sprintf("sudo route -n add -net %v -gateway 114.2.2.2 -hopcount 1", a)).Run()
	if err != nil {
		log.Println(fmt.Sprintf("set route err:%v", err))
	}
}

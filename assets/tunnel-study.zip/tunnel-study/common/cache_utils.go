package common

import (
	"errors"
	"sync"
)

type CurrentMap[T interface{}] struct {
	s sync.Map
	//s map[string]any
}

func (c *CurrentMap[T]) Del(s string) error {
	c.s.Delete(s)
	return nil
}
func (c *CurrentMap[T]) Set(s string, t T) error {
	c.s.Store(s, t)
	return nil
}

func (c *CurrentMap[T]) Get(s string) (t T, err error) {
	//value := c.s[s]
	value, ok := c.s.Load(s)
	if !ok {
		return t, errors.New("get val is nil!")
	}
	t, ok = value.(T)
	if !ok {
		return t, errors.New("get val type error!")
	}
	return t, nil
}

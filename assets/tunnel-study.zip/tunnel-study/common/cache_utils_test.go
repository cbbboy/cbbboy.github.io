package common

import (
	"fmt"
	"io"
	"testing"
	"time"
)

func TestCache(t *testing.T) {
	reader, writer := io.Pipe()
	c := &CurrentMap[io.Reader]{}
	c.Set("11", reader)

	get, err := c.Get("11")
	if err != nil {
		fmt.Println(err)
		return
	}
	go func() {
		buf := make([]byte, 1023)
		read, err := get.Read(buf)
		if err != nil {
			fmt.Println(err)
			return
		}
		fmt.Println(string(buf[:read]))
	}()
	go func() {
		i := []byte("hello reader!!")
		_, err := writer.Write(i)
		if err != nil {
			fmt.Println(err)
			return
		}
	}()
	time.Sleep(2 * time.Second)
}

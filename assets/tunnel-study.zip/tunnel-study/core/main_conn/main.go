package main_conn

import (
	"fmt"
	"net"
	"sync"
	"tunnel-study/common"
	"tunnel-study/core/protocol"
)

type MainConn struct {
	Session uint32
	// 和客户端连接
	C net.Conn

	// client givor出来的conn
	// server 和后端服务真实连接
	// 可以并发的map
	SubTcpConn *common.CurrentMap[net.Conn]
	SubUdpConn *common.CurrentMap[net.Conn]

	// 防止多次关闭
	sync.Once
}

func (m *MainConn) DoProcess(b []byte) (err error) {
	_, err = protocol.Read(m.C)
	if err != nil {
		return err
	}
	// 判断 process id
	_, err = m.C.Read(b)

	err = Process[b[0]](m, b)
	if err != nil {
		return err
	}
	return nil
}

func (m *MainConn) SetProcess(b []byte, process uint8) (n int, err error) {
	// todo 优化内存拷贝
	return m.C.Write(append([]byte{process}, b...))
}

func (m *MainConn) Close() error {
	m.Once.Do(func() {
		m.C.Close()
	})
	return nil
}

func (m *MainConn) StartProcess() {
	defer func() {
		a := recover()
		if a != nil {
			fmt.Println(fmt.Sprintf("accept recover error:%v", a))
		}
	}()
}

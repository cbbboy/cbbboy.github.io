package main_conn

const (
	TcpData          = 0
	TcpConnect       = 1
	TcpConnectAccept = 3
	TcpReject        = 4
	TcpDisConnect    = 9

	UdpData = 10

	Message = 100
)

var Process = make(map[byte]func(*MainConn, []byte) error)

func init() {
	// tcp连接
	Process[TcpConnect] = processTcpConnect
	//tcp断开
	Process[TcpDisConnect] = processTcpDisConnect
	// tcp数据
	Process[TcpData] = processTcpData

	// tcp 接受拒绝回掉
	Process[TcpConnectAccept] = processTcpConnectAccept
	Process[TcpReject] = processTcpReject

	//udp
	Process[UdpData] = processUdpData

	// 消息
	Process[Message] = processMessage
}

// tcp 接受拒绝回掉
func processTcpConnect(m *MainConn, buf []byte) error {
	return nil
}

// tcp 接受拒绝回掉
func processTcpReject(m *MainConn, buf []byte) error {
	return nil
}

// tcp 接受拒绝回掉
func processTcpConnectAccept(m *MainConn, buf []byte) error {
	return nil
}

// tcp断开
func processTcpDisConnect(m *MainConn, buf []byte) error {
	return nil
}

// 9
func processTcpData(m *MainConn, buf []byte) error {
	return nil
}

// udp
func processUdpData(m *MainConn, buf []byte) error {
	return nil
}

// 消息通知
func processMessage(m *MainConn, buf []byte) error {
	return nil
}

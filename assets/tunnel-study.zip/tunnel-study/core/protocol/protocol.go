package protocol

import (
	"io"
	"unsafe"
)

type protocolPre int32

var preLenSize = unsafe.Sizeof(protocolPre(0))

func Read(reader io.Reader) ([]byte, error) {
	// todo []byte池不用每次申请内存
	pre := make([]byte, preLenSize)
	_, err := io.ReadFull(reader, pre)
	if err != nil {
		return nil, err
	}
	// 如果采用大端方案
	// [ 2 0 0 0] 即为 2
	ppl := protocolPre(int32(pre[3])<<24 + int32(pre[2])<<16 + int32(pre[1])<<8 + int32(pre[0]))

	buf := make([]byte, ppl)
	_, err = io.ReadFull(reader, buf)
	if err != nil {
		return nil, err
	}
	return buf, nil
}
func Write(writer io.Writer, buf []byte) (int, error) {
	// 放入buf长度
	pre := make([]byte, 4)

	// 如果采用大端方案
	// [ 2 0 0 0] 即为 2
	bl := len(buf)
	pre[0] = byte(bl)
	pre[1] = byte(bl >> 8)
	pre[2] = byte(bl >> 16)
	pre[3] = byte(bl >> 24)

	// todo 考虑拷贝次数减少
	return writer.Write(append(pre, buf...))
}

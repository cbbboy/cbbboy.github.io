package protocol

import (
	"bytes"
	"fmt"
	"io"
	"testing"
	"time"
	"unsafe"
)

func Test001(t *testing.T) {
	var preLenSize = unsafe.Sizeof(protocolPre(0))
	fmt.Println(preLenSize)
}

func TestRead(t *testing.T) {
	//pipe.NewPipe()
	r, w := io.Pipe()
	go func() {
		read, err := Read(r)
		if err != nil {
			fmt.Println(err)
			return
		}
		fmt.Println(string(read))
	}()
	go func() {
		i := []byte("hello reader!!")
		_, err := Write(w, i)
		if err != nil {
			fmt.Println(err)
			return
		}
	}()
	time.Sleep(2 * time.Second)
}

func TestWrite(t *testing.T) {
	type args struct {
		buf []byte
	}
	tests := []struct {
		name       string
		args       args
		wantWriter string
		want       int
		wantErr    bool
	}{}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			writer := &bytes.Buffer{}
			got, err := Write(writer, tt.args.buf)
			if (err != nil) != tt.wantErr {
				t.Errorf("Write() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotWriter := writer.String(); gotWriter != tt.wantWriter {
				t.Errorf("Write() gotWriter = %v, want %v", gotWriter, tt.wantWriter)
			}
			if got != tt.want {
				t.Errorf("Write() got = %v, want %v", got, tt.want)
			}
		})
	}
}

package main

import (
	"fmt"
	"math/rand"
	"net"
	"tunnel-study/common"
	"tunnel-study/core/main_conn"
)

func main() {
	listen, err := net.Listen("tcp", "0.0.0.0:123")
	if err != nil {
		fmt.Println(err)
		return
	}
	for {
		conn, err := listen.Accept()
		if err != nil {
			fmt.Println(err)
			return
		}
		session := rand.Uint32()
		fmt.Println("accept session:%v local:%v remote:%v", session, conn.LocalAddr().String(), conn.RemoteAddr().String())
		mainConn := &main_conn.MainConn{
			Session:    session,
			C:          conn,
			SubTcpConn: &common.CurrentMap[net.Conn]{},
			SubUdpConn: &common.CurrentMap[net.Conn]{},
		}
		go mainConn.StartProcess()
	}
}

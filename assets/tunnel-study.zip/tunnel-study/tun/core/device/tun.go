//go:build !windows

// Package tun provides TUN which implemented device.Device interface.
package device

const (
	Driver     = "tun"
	offset     = 4
	defaultMTU = 1500 /* auto */
)

func (t *TUN) Type() string {
	return Driver
}

var _ Device = (*TUN)(nil)

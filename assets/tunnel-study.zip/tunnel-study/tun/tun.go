//go:build !(ios || android_sdk || windows)
// +build !ios,!android_sdk,!windows

package tun

import (
	"fmt"
	"net/url"
	"strings"
	"tunnel-study/tun/core/device"
)

func CreateDevice(s string, mtu uint32) (device.Device, error) {
	if !strings.Contains(s, "://") {
		s = fmt.Sprintf("%s://%s", device.Driver /* default driver */, s)
	}

	u, err := url.Parse(s)
	if err != nil {
		return nil, err
	}

	name := u.Host
	driver := strings.ToLower(u.Scheme)

	switch driver {
	case device.Driver:
		return device.Open(name, mtu)
	default:
		return nil, fmt.Errorf("unsupported driver: %s", driver)
	}
}

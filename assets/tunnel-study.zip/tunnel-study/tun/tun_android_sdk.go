//go:build client && android_sdk

package tun

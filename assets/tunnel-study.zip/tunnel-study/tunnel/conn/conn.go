package conn

import (
	"gvisor.dev/gvisor/pkg/tcpip/stack"
	"net"
)

type TCPConn interface {
	net.Conn
}

// UDPConn implements net.Conn and net.PacketConn.
type UDPConn interface {
	net.Conn
	net.PacketConn

	// ID returns the transport endpoint id of UDPConn.
	ID() *stack.TransportEndpointID
}

package tunnel

import (
	"fmt"
	"io"
	"net"
	"time"
)

var (
	udpTimeout = 5 * time.Second
)

// 本地放行+重写目的地址
func tcpProcessRewrite(conn net.Conn) {
	fmt.Println(fmt.Sprintf("TCP ProcessRewrite dst remote addr:%v local addr:%v", conn.RemoteAddr().String(), conn.LocalAddr().String()))
	local, _ := net.ResolveTCPAddr("tcp", "10.11.36.35")
	remote, _ := net.ResolveTCPAddr("tcp", "10.50.1.18:8088")
	tcpConn, err := net.DialTCP("tcp", local, remote)
	if err != nil {
		fmt.Println(fmt.Sprintf("net dial error:%v", err))
		return
	}
	go func() {
		defer conn.Close()
		io.Copy(tcpConn, conn)
	}()
	go func() {
		defer tcpConn.Close()
		io.Copy(conn, tcpConn)
	}()
}
func udpProcessRewrite(conn net.Conn) {
	fmt.Println(fmt.Sprintf("UDP ProcessRewrite dst remote addr:%v local addr:%v", conn.RemoteAddr().String(), conn.LocalAddr().String()))
	local, _ := net.ResolveUDPAddr("udp", "10.11.36.35")
	remote, _ := net.ResolveUDPAddr("udp", "10.50.1.18:9999")
	udpConn, err := net.DialUDP("udp", local, remote)
	if err != nil {
		fmt.Println(fmt.Sprintf("net dial error:%v", err))
		return
	}
	go func() {
		defer func() {
			conn.Close()
			fmt.Println("remote to local close!")
		}()
		buf := make([]byte, 1024*32)
		for {
			udpConn.SetDeadline(time.Now().Add(udpTimeout))

			nr, err := udpConn.Read(buf)
			if err != nil {
				return
			}
			_, err = conn.Write(buf[0:nr])
			if err != nil {
				return
			}
		}

		//io.Copy(udpConn, conn)
	}()

	go func() {
		defer func() {
			fmt.Println("local to remote close!")
			udpConn.Close()
		}()
		buf := make([]byte, 1024*32)
		for {
			udpConn.SetDeadline(time.Now().Add(udpTimeout))

			nr, err := conn.Read(buf)
			if err != nil {
				return
			}
			_, err = udpConn.Write(buf[0:nr])
			if err != nil {
				return
			}
		}
	}()
}

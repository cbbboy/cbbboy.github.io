package tunnel

import (
	"fmt"
	"net"
)

func tcpProcessTunnel(conn net.Conn) {
	fmt.Println(fmt.Sprintf("TCP remote addr:%v local addr:%v", conn.RemoteAddr().String(), conn.LocalAddr().String()))

}
func udpProcessTunnel(conn net.Conn) {
	fmt.Println(fmt.Sprintf("UDP remote addr:%v local addr:%v", conn.RemoteAddr().String(), conn.LocalAddr().String()))
}

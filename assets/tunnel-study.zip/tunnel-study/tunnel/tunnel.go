package tunnel

import (
	"log"
	"tunnel-study/tunnel/conn"
)

const (
	// maxUDPQueueSize is the max number of UDP packets
	// could be buffered. if queue is full, upcoming packets
	// would be dropped util queue is ready again.
	maxUDPQueueSize = 1 << 9
)

var (
	_tcpQueue = make(chan conn.TCPConn) /* unbuffered */
	_udpQueue = make(chan conn.UDPConn, maxUDPQueueSize)
	//_numUDPWorkers = max(runtime.NumCPU(), 4 /* at least 4 workers */)
)

func InitProcess() {
	go func() {
		process()
	}()
}

// Add adds tcpConn to tcpQueue.
func Add(conn conn.TCPConn) {
	_tcpQueue <- conn
}

// AddPacket adds udpPacket to udpQueue.
func AddPacket(packet conn.UDPConn) {
	select {
	case _udpQueue <- packet:
	default:
		log.Println("queue is currently full, packet will be dropped")
		packet.Close()
	}
}

// 在这里处理业务流量
func process() {
	for {
		select {
		case tcpConn := <-_tcpQueue:
			go tcpProcessRewrite(tcpConn)
		case udpPacket := <-_udpQueue:
			go udpProcessRewrite(udpPacket)
		}
	}
}
